<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "online2d";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$result = $conn->query("SELECT * FROM users WHERE isLogin=1");
if($result->num_rows == 0) {
     echo "true"; //No one is logged
} else {
  $sql = "UPDATE users SET isLogin=0 WHERE isLogin=1";

  if ($conn->query($sql) === TRUE) {
    echo "false";
  } else {
    echo "A problem occured";
  }
}
$conn->close();