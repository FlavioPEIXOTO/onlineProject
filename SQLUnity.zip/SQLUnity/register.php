<?php

/*$con = mysql_connect('localhost', 'root', '', 'online2d');

if (mysql_connect_errno()){
    echo "1";
    exit();
}

$username = $_POST["Username"];
$pass = $_POST["User_pass"];

$namecheckquery = "SELECT Username FROM users WHERE Username='" .$username . "';"
$namecheck = mysqli_query($con, $namecheckquery) or die("2: Name check query failed");

if (mysqli_num_rows($namecheck)> 0){
    echo "3: Name already exist";
    exit();
}

$insertuserquery = "INSERT INTO users (Username, User_pass) VALUES('". $username . "', '" . $pass . "');"
mysqli_query($con, $insertuserquery) or die("4: Insert player query failed");

echo("0");*/

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "online2d";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$User_name = $_POST["Username"];
$User_password = $_POST["User_pass"];

$result = $conn->query("SELECT * FROM users WHERE Username = '$User_name'");
if($result->num_rows > 0) {
     echo 'Username already exist';
}
else{
    $sql = "INSERT INTO users (Username, User_pass)
    VALUES ('". $User_name . "', '" . $User_password . "')";

    if ($conn->query($sql) === TRUE) {
    echo "false";
    } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();

?>