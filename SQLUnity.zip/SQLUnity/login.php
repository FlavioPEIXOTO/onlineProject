<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "online2d";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$User_name = $_POST["Username"];
$User_password = $_POST["User_pass"];

$result = $conn->query("SELECT * FROM users WHERE Username = '$User_name'");
if($result->num_rows == 0) {
     echo "Username or password uncorrect";
} else {
  $sql = "UPDATE users SET isLogin=1 WHERE Username='$User_name'";

  if ($conn->query($sql) === TRUE) {
    echo "false";
  } else {
    echo "A problem occured";
  }
}
$conn->close();

?>